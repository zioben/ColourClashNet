﻿using ColourClashNet.Defaults;
using ColourClashNet.Imaging;
using ColourClashNet.Log;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ColourClashNet.Color.Transformation
{
    public class ColorTransformReductionAmiga : ColorTransformBase
    {
        static string sC = nameof(ColorTransformReductionAmiga);


        public enum EnumAmigaVideoMode
        {
            Ham6,
            Ham8,
            ExtraHalfBright
        }

        public enum EnumHamColorProcessingMode
        {
            Fast,
            Detailed
        }

        public EnumAmigaVideoMode AmigaVideoMode { get; set; } = EnumAmigaVideoMode.Ham6;

        public EnumHamColorProcessingMode HamColorProcessingMode { get; set; } = EnumHamColorProcessingMode.Fast;

        public ColorTransformReductionAmiga()
        {
            Type = ColorTransformType.ColorReductionClustering;
            Description = "Commododre Amiga specific color reduction";
        }


        internal protected override ColorTransformInterface SetProperty(ColorTransformProperties propertyName, object value)
        {
            base.SetProperty(propertyName, value);
            switch (propertyName)
            {
                case ColorTransformProperties.AmigaVideoMode:
                        AmigaVideoMode = ToEnum<EnumAmigaVideoMode>(value);
                    break;
                case ColorTransformProperties.AmigaHamColorProcessingMode:
                        HamColorProcessingMode = ToEnum<EnumHamColorProcessingMode>(value);
                    break;
                default:
                    break;
            }
            return this;
        }

      


        // Not Needed
        // protected async override Task<ColorTransformResults> CreateTrasformationMapAsync(CancellationToken? oToken)


        ImageData ToHam(ImageData oDataSource, ImageData oDataPreProcessed, ColorQuantizationMode eQuantization)
        {

            var oQuantization = new ColorTransformQuantization();
            oQuantization.QuantizationMode = eQuantization;
            oQuantization.Create(oDataPreProcessed);

            var oHamData = new int[oDataSource.Rows, oDataSource.Columns];
            for (int r = 0; r < oDataSource.Rows; r++)
            {
                int iRgbPrev = ColorDefaults.DefaultInvalidColorInt; ;
                var oPalette = new Palette();
                for (int c = 1; c < oDataSource.Columns; c++)
                {
                    if (iRgbPrev < 0)
                    {
                        iRgbPrev = oDataPreProcessed.matrix[r, c];
                        oHamData[r, c] = iRgbPrev;
                        continue;
                    }
                    else
                    {
                        int iRgbSrc = oQuantization.QuantizeColor( oDataSource.matrix[r, c] );
                        if (iRgbSrc < 0)
                        {
                            iRgbPrev = ColorDefaults.DefaultInvalidColorInt;
                            oHamData[r, c] = iRgbSrc;
                            continue;
                        }
                        int pR = iRgbPrev.ToR();
                        int pG = iRgbPrev.ToG();
                        int pB = iRgbPrev.ToB();
                        int sR = iRgbSrc.ToR();
                        int sG = iRgbSrc.ToG();
                        int sB = iRgbSrc.ToB();
                        int iHamO = oQuantization.QuantizeColor( oDataPreProcessed.matrix[r,c] );
                        int iHamR = ColorIntExt.FromRGB(sR, pG, pB);
                        int iHamG = ColorIntExt.FromRGB(pR, sG, pB);
                        int iHamB = ColorIntExt.FromRGB(pR, pG, sB);
                        oPalette.Reset();
                        oPalette.Add(iHamO);
                        oPalette.Add(iHamR);
                        oPalette.Add(iHamG);
                        oPalette.Add(iHamB);
                        var oCol = oQuantization.QuantizeColor( ColorIntExt.GetNearestColor(iRgbSrc, oPalette, ColorDistanceEvaluationMode) );
                        iRgbPrev = oCol;
                        oHamData[r,c] = oCol;   
                    }
                }
            }
            return new ImageData().Create( oHamData );
        }

        //int[,]? ToEhb(int[,]? oDataSource, int[,]? oDataPreProcessed, CancellationToken? oToken)
        //{
        //    return await Task.Run(() => { return new int[,]; } );
        //}

        protected  override ColorTransformResult ExecuteTransform(CancellationToken token = default)
        {
            string sM = nameof(ExecuteTransform);

            ColorTransformInterface oColorReduction;
            var oQuantization = new ColorTransformQuantization()
                .SetProperty(ColorTransformProperties.PriorityPalette, PriorityPalette)
                .SetProperty(ColorTransformProperties.DitheringType, DitheringType)
                .SetProperty(ColorTransformProperties.DitheringStrength, DitheringStrength)
                .SetProperty(ColorTransformProperties.DitheringFx, DitheringFx)
               ;

            int iMaxColors = 0;

            switch (AmigaVideoMode)
            {
                case EnumAmigaVideoMode.ExtraHalfBright:
                    iMaxColors = 64;
                    oQuantization.SetProperty(ColorTransformProperties.QuantizationMode, ColorQuantizationMode.RGB444);
                    break;
                case EnumAmigaVideoMode.Ham6:
                    iMaxColors = 16;
                    oQuantization.SetProperty(ColorTransformProperties.QuantizationMode, ColorQuantizationMode.RGB444);
                    break;
                case EnumAmigaVideoMode.Ham8:
                    iMaxColors = 64;
                    oQuantization.SetProperty(ColorTransformProperties.QuantizationMode, ColorQuantizationMode.RGB666);
                    break;
                default:
                    return null;
            }

            var oResultQuantized = oQuantization.CreateAndProcessColors(ImageSource, token);

            switch (HamColorProcessingMode)
            {
                default:
                case  EnumHamColorProcessingMode.Fast:
                    {
                        oColorReduction = new ColorTransformReductionMedianCut()
                            .SetProperty(ColorTransformProperties.UseColorMean, true)
                            .SetProperty(ColorTransformProperties.ColorDistanceEvaluationMode, ColorDistanceEvaluationMode)
                            .SetProperty(ColorTransformProperties.MaxColorsWanted, iMaxColors)
                            .SetProperty(ColorTransformProperties.DitheringType, DitheringType)
                            .SetProperty(ColorTransformProperties.DitheringStrength, DitheringStrength)
                            .SetProperty(ColorTransformProperties.DitheringFx, DitheringFx);
                    }
                    break;
                case EnumHamColorProcessingMode.Detailed:
                    {
                        oColorReduction = new ColorTransformReductionCluster()
                            .SetProperty(ColorTransformProperties.UseColorMean, true)
                            .SetProperty(ColorTransformProperties.ColorDistanceEvaluationMode, ColorDistanceEvaluationMode)
                            .SetProperty(ColorTransformProperties.MaxColorsWanted, iMaxColors)
                            .SetProperty(ColorTransformProperties.DitheringType, DitheringType)
                            .SetProperty(ColorTransformProperties.DitheringStrength, DitheringStrength)
                            .SetProperty(ColorTransformProperties.DitheringFx, DitheringFx)
                            .SetProperty(ColorTransformProperties.ClusterTrainingLoop, 10);
                    }
                    break;
            }


            var oDataPreprocessedResult = oColorReduction.CreateAndProcessColors(oResultQuantized.DataOut, token);
            BypassDithering = true;

            ImageData? oAmigaData; 
            switch (AmigaVideoMode)
            {
                case EnumAmigaVideoMode.Ham6:
                    oAmigaData = ToHam(ImageSource, oDataPreprocessedResult.DataOut, ColorQuantizationMode.RGB444 );
                    break;
                case EnumAmigaVideoMode.Ham8:
                    oAmigaData = ToHam(ImageSource, oDataPreprocessedResult.DataOut, ColorQuantizationMode.RGB666 );
                    break;
                case EnumAmigaVideoMode.ExtraHalfBright:
                    oAmigaData = null;
                    //oRet = ToEhb(oDataSource, oDataPreprocessed, oToken );
                    break;
                default:
                    oAmigaData = null;
                    break;
            }
            if (oAmigaData == null)
            {
                LogMan.Error(sC, sM, $"Failed to generate Amiga transformed data");
                return ColorTransformResult.CreateErrorResult(ImageSource,null, $"{sC}.{sM} : Amiga transformed data is null");
            }
            return ColorTransformResult.CreateValidResult(ImageSource, oAmigaData);
        }

    }
}
