﻿using ColourClashNet.Color;
using ColourClashNet.Color.Transformation;
using ColourClashNet.Imaging;
using ColourClashNet.Log;
using ColourClashProcessing.Threshold;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace ColourClashProcessing.Blob
{
    public class Blob
    {
        static String sC = nameof(Blob);

        GlobalThreshold threshold = new GlobalThreshold();
        Shape shape = new Shape();

        public Palette ThresholdPalette { get; private set; } = new Palette();

        public double ThresholdTolerance { get; private set; } = 0.0;

        public bool InvertThresholdResults { get; private set; } = false;

        public BlobConnectionModes ConnectionMode { get; private set; } = BlobConnectionModes.FourConnected;

        public bool Valid => shape.Valid && _connectedComponents != null;

        Dictionary<int, List<RunLength>>? _connectedComponents = null;

        public Blob()
        {
            Reset();
        }

        public void Reset()
        {
            threshold = new GlobalThreshold();
            shape = new Shape();
            ThresholdPalette = new Palette().Create(new List<int>() { ColorIntExt.FromRGB(255, 0, 255) });
            ThresholdTolerance = 0.0;
            InvertThresholdResults = false;
            ConnectionMode = BlobConnectionModes.FourConnected;
            _connectedComponents = null;
        }


        public Blob WithThreshold(Palette thresholdPalette, double toleranceFactor = 0.0, bool invertResults = false)
        {
            ThresholdPalette = new Palette().Create(thresholdPalette);
            ThresholdTolerance = toleranceFactor;
            InvertThresholdResults = invertResults;
            threshold.WithThreshold(ThresholdPalette, ThresholdTolerance, InvertThresholdResults);
            return this;
        }

        public Blob WithProcessing(BlobConnectionModes connectionMode)
        {
            ConnectionMode = connectionMode;
            return this;
        }

        

        public ColorTransformResult Process(ImageData image, CancellationToken cancellationToken = default)
        {
            string sM = nameof(Process);
            try
            {
                Reset();
                ImageData.AssertValid(image);
                var thresholdResult = threshold.Process(image, cancellationToken);
                if (!thresholdResult.IsSuccess)
                {
                    LogMan.Error(sC,sM, $"Threshold processing failed: {thresholdResult.Message}", thresholdResult.Exception);
                    return thresholdResult;
                }
                var shapeResult = shape.Process(thresholdResult.DataOut, cancellationToken);
                if (!shapeResult.IsSuccess)
                {
                    LogMan.Error(sC,sM, $"Shape processing failed: {shapeResult.Message}", shapeResult.Exception);
                    return shapeResult;
                }


                return ColorTransformResult.CreateValidResult(shapeResult.DataIn, shapeResult.DataOut, "Blob processing completed successfully.");
            }
            catch (Exception ex)
            {
                return ColorTransformResult.CreateErrorResult($"Exception during blob processing: {ex.Message}", ex);
            }
        }

    }
}
