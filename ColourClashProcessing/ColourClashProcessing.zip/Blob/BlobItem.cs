﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColourClashProcessing.Blob
{
    public class BlobItem
    {
        int BlobId { get; set; } = -1;
        public int Area { get; set; } = 0;
        public int XMin { get; set; } = -1;
        public int XMax { get; set; } = -1;
        public int YMin { get; set; } = -1;
        public int YMax { get; set; } = -1;
        public List<RunLength> RunLengths { get; private set; } = new List<RunLength>();


    }
}
