﻿using ColourClashNet.Color;
using ColourClashNet.Color.Transformation;
using ColourClashNet.Imaging;
using ColourClashNet.Log;
using System;
using System.Collections.Generic;
using System.Text;

namespace ColourClashProcessing.Blob
{
    public class Shape
    {
        static string sC = nameof(Shape);

        public List<RunLength> RunLengths { get; protected set; } = new List<RunLength>();

        int SourceWidth { get; set; } = 0;
        int SourceHeight { get; set; } = 0;   

        public bool Valid => SourceWidth > 0 && SourceHeight > 0;

        public void Reset()
        {
            RunLengths.Clear();
            SourceWidth = 0;
            SourceHeight = 0;
        }

        public ColorTransformResult Process(ImageData image, CancellationToken token = default)
        {
            string sM = nameof(Process);
            try
            {
                Reset();
                ImageData.AssertValid(image);
                var matrix = image.GetMatrix();
                int R = matrix.GetLength(0);
                int C = matrix.GetLength(1);

                Parallel.For(0, R, (r, state) =>
                {
                    token.ThrowIfCancellationRequested();
                    int c = 0;
                    while (c < C)
                    {
                        int color = matrix[r, c];
                        if (color != 0)
                        {
                            int startC = c;
                            while (c < C && matrix[r, c] != 0)
                            {
                                c++;
                            }
                            int endC = c - 1;
                            RunLengths.Add(new RunLength(r, startC, endC));
                        }
                        else
                        {
                            c++;
                        }
                    }
                });
                RunLengths.Sort((X, Y) => X.R < Y.R ? 1 : X.CS < Y.CS ? 1 : -1);
                SourceWidth = C;
                SourceHeight = R;
                return ColorTransformResult.CreateValidResult(image, null, $"Processed {RunLengths.Count} run lengths");
            }
            catch (OperationCanceledException cex)
            {
                LogMan.Exception(sC, sM, $"Operation canceled", cex);
                return ColorTransformResult.CreateErrorResult(image, null, $"Operation canceled", cex);
            }
            catch (Exception ex)
            {
                LogMan.Exception(sC, sM, $"Operation failed", ex);
                throw;
            }
        }

        public ColorTransformResult ToImageData()
        {
            string sM = nameof(ToImageData);
            try
            {
                if (!Valid)
                {
                    return ColorTransformResult.CreateErrorResult(null, null, $"No run lengths to convert to image data");
                }
                var matrix = new int[SourceHeight, SourceWidth];
                var col = ColorIntExt.FromRGB(255, 255, 255);
                foreach (var rl in RunLengths)
                {
                    for (int c = rl.XS; c <= rl.XE; c++)
                    {
                        matrix[rl.Y, c] = col;
                    }
                }
                var imageOut = new ImageData().Create(matrix);
                return ColorTransformResult.CreateValidResult(null, imageOut, $"Converted {RunLengths.Count} run lengths to image data");
            }
            catch (Exception ex)
            {
                LogMan.Exception(sC, sM, $"Operation failed", ex);
                throw;
            }
        }
    }
}
